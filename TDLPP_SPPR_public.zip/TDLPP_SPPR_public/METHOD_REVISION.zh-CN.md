# SPPR 方法段与实现同步修改稿

本稿对应 `unique_candidate_greedy_softclip_frozen_v2`。下述 SPPR 替换文字是针对早期采用独立选择描述的稿件保留的历史草稿。2026-10-02 核对的 `SGTDLPP_202603 (1).pdf` 式（15）–（16）已经包含顺序无放回选择及耗尽回退，不应重复声称最新版 PDF 仍采用独立选择。下述初始化、停止历史及实验说明仍可用于核对实现细节；本文件未直接改写任何论文源文件。

## Draft

To limit repeated use of the same candidate within a patch, we construct the candidate assignment sequentially without replacement. Let the heterogeneous positions be ordered as \(p_{i,1},\ldots,p_{i,L_i}\), where \(L_i=|\mathcal H_i|\). Positions are visited row by row, from top to bottom and from left to right. At step \(t\), the available candidate set is

\[
\Omega'_{i,t}=\Omega'_i\setminus\mathcal U_{i,t-1},
\qquad \mathcal U_{i,0}=\varnothing. \tag{15}
\]

If \(\Omega'_{i,t}\ne\varnothing\), the candidate is selected by

\[
p^*_{i,t}=\underset{p'\in\Omega'_{i,t}}{\arg\min}\ s(p',p_{i,t}),
\qquad
\mathcal U_{i,t}=\mathcal U_{i,t-1}\cup\{p^*_{i,t}\}. \tag{16}
\]

Ties are resolved by ascending original-scene linear index, using MATLAB's column-major indexing. Each candidate can therefore be assigned at most once within a patch. If the available set is empty, the original spectrum is retained at that position and at subsequent heterogeneous positions. This procedure is a deterministic greedy assignment; it does not claim to solve a global minimum-cost matching problem.

For an assigned position, reconstruction follows Eq. (17), with the same adaptive interpolation weight. The heterogeneous proportion \(\rho_i\) is calculated from the original pseudo-label mask and is not recomputed after assignment. Homogeneous and unassigned positions remain unchanged. Equivalently, the correction spectrum at an unassigned position is defined as its original spectrum, so that the interpolation produces no change.

## 保留与替换范围

- 保留式（10）–（14）的掩膜、初始候选集及评分。
- 用上述递归候选集与顺序贪心选择替换式（15）–（16）的独立选择定义。
- 删除“不同位置决策独立”和因此可以独立求解全局目标的表述。
- 保留式（17）的自适应插值形式，补充无候选时保留原光谱的说明。
- 对称边界用于 patch 取样；候选只来自原图，评分采用异质位置的空间参考坐标。该实现细节可写入补充材料。
- 复杂度仍可使用上界 \(O(Q_i|\mathcal H_i|)\)：每步扫描未使用候选，不超过初始候选数。它不是全局匹配求解器的复杂度。

## TDLPP Algorithm 1 的实现说明

冻结求解器在每轮模式更新前记录并检查当前目标函数。为与代码一致，可将迭代部分写成如下伪代码，图构建、特征方程和阈值保持原定义：

Initialize the projections as \(U_1=\operatorname{eye}(1,s)\), \(U_2=\operatorname{eye}(1,s)\), and \(U_3=\operatorname{eye}(d,m)\), where \(s\) is the spatial window width, \(m\) is the spectral input dimension after preprocessing, \(d\) is the requested spectral output dimension, and \(\operatorname{eye}(a,b)\) denotes the rectangular identity initialization used in the implementation.

```text
Initialize the projection matrices and build W and B.
for t = 1,...,50:
    Evaluate the current within/between ratio J.
    If t > 1 and the change from the preceding recorded J is below 0.005:
        stop and return the current projection matrices.
    Update U1, U2 and U3 in sequence.
Return the current projection matrices.
```

达到50次上限时，最后一次记录的目标函数位于最后一次更新之前；代码同时保存记录次数与实际更新次数。不要把它标成最终更新后的目标值。

数值实现保留原来的 `eig(S_B,S_W)`、降序排序及 `lambda>eps` 筛选，不增加正则化、强制对称化或额外的非有限/复数筛选。请求维数与实际保留维数均应记录；浮点计算保留的近零方向不能直接称为独立的精确非零判别方向。此说明披露实现行为，不把它扩展为额外的理论保证。

## 实验说明的补充文字

For the additional validation, we used ten saved random splits with MATLAB Twister seeds 1001–1010. Indian Pines and Houston used floor(5% per class), and Salinas used floor(1% per class), with at least ten training samples per class. HongHu used 50 training and 300 testing samples per class. All four datasets used an 11×11 window, with spectral output dimensions of 50, 50, 20 and 15, respectively. HongHu was preprojected to 80 dimensions using full-scene PCA. Raw and reconstructed patches used the same split, and their training and testing partitions were centered separately. The frozen ERS partitions were shared across all splits. These are additional fixed-split validations, rather than a reconstruction of the unpublished original manuscript splits.

## Terminology ledger

| 规范名称或符号 | 定义 | 使用决定 |
|---|---|---|
| SPPR | Superpixel-guided Patch Purification Reconstruction | 保留原稿名称 |
| SoftClip | 自适应插值幅度约束 | 插值形式保持式（17） |
| \(\Omega'_i\) | 初始可用同伪标签候选集 | 不包含已保留同质位置 |
| \(\mathcal U_{i,t}\) | 当前 patch 已使用的候选 | 不跨 patch 共享 |
| \(\mathcal H_i\), \(\rho_i\) | 原异质掩膜位置集合及比例 | 分配后不更新 |
| CLCR | Center Label Consistency Ratio | 只诊断插值前硬分配，不赋予混合光谱来源真类 |

## Claim-evidence map 与范围

- 候选不复用、固定顺序、耗尽回退：由实际实现及组件测试支持。
- 自适应修改幅度：由原式（17）、冻结函数及对照支持；不等于证明所有位置更接近真实中心类别。
- 四数据集增益：只引用对应固定方法、划分和窗口的实际验收结果。
- 禁止候选复用一定提高精度或语义纯度：现有证据不支持这种普遍结论，正文不加入该断言。

原稿表10及图6–8涉及历史结果和其它方法，仍应核对它们各自的生成实现。这次40组验收只覆盖四数据集的11×11 TDLPP配对实验，不能替代其它方法、窗口或 CLCR 图的重算。缺少原稿逐组来源时，保留明确的证据范围，不把截图新实验改称原稿原始实验。
