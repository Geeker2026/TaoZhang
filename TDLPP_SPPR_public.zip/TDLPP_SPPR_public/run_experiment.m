function [summary,run_root] = run_experiment(dataset,data_root,output_root,cfg,split_file)
%RUN_EXPERIMENT Frozen screenshot splits/maps by default; paired full refit.
root=setup();
if nargin<1 || isempty(dataset), dataset='Indian'; end
if nargin<2 || isempty(data_root), data_root=fullfile(root,'data'); end
if nargin<3 || isempty(output_root), output_root=fullfile(root,'output'); end
if nargin<4 || isempty(cfg), cfg=paper_config(dataset); end
if nargin<5, split_file=''; end
cube_file=fullfile(data_root,cfg.folder,cfg.cube_file);
gt_file=fullfile(data_root,cfg.folder,cfg.gt_file);
assert(exist(cube_file,'file')==2 && exist(gt_file,'file')==2,'Missing external data files.');
fingerprints=struct('cube',file_sha256(cube_file),'gt',file_sha256(gt_file));
if strcmp(cfg.segmentation_source,'frozen')
    manifest=jsondecode(fileread(fullfile(root,'reproducibility','INPUT_MANIFEST.json')));
    names={['data/' cfg.folder '/' cfg.cube_file],['data/' cfg.folder '/' cfg.gt_file]};
    hashes={fingerprints.cube,fingerprints.gt};
    for k=1:2
        i=find(strcmp({manifest.path},names{k}),1);
        assert(~isempty(i) && strcmp(manifest(i).sha256,hashes{k}), ...
            'Frozen protocol input differs: %s. Use a separate recompute protocol.',names{k});
    end
end
a=load(cube_file,cfg.cube_variable); b=load(gt_file,cfg.gt_variable);
X=preprocess_cube(a.(cfg.cube_variable),cfg); gt=double(b.(cfg.gt_variable)); clear a b
[state,segmentation]=sppr_segment(X,cfg);
if ~isempty(split_file)
    splits=load_frozen_splits(gt,cfg,split_file);
elseif strcmp(cfg.split_source,'frozen')
    splits=load_frozen_splits(gt,cfg);
else
    assert(strcmp(cfg.split_source,'generated'),'Unknown split source.');
    splits=arrayfun(@(seed)make_split(gt,cfg,seed),cfg.seeds);
end
if ~exist(output_root,'dir'), mkdir(output_root); end
run_id=[cfg.dataset '_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))];
run_root=fullfile(output_root,run_id); assert(~exist(run_root,'dir')); mkdir(run_root);
save(fullfile(run_root,'protocol.mat'),'cfg','splits','segmentation','fingerprints');
records=zeros(numel(splits),10);
for k=1:numel(splits)
    result=run_pipeline(X,gt,splits(k),cfg,state);
    result.segmentation=segmentation;
    result.source=struct('cube_file',cube_file,'gt_file',gt_file,'fingerprints',fingerprints, ...
        'matlab_version',version,'ers_file',which('mex_ers'));
    raw=result.Raw_TDLPP.metrics; purified=result.SPPR_TDLPP.metrics;
    records(k,:)=[splits(k).seed,raw.OA,raw.AA,raw.Kappa,purified.OA, ...
        purified.AA,purified.Kappa,result.OA_gain, ...
        result.Raw_TDLPP.model.effective_dimension,result.SPPR_TDLPP.model.effective_dimension];
    save(fullfile(run_root,sprintf('trial_%02d_seed_%d.mat',k,splits(k).seed)),'result','-v7.3');
    fprintf('%s seed %d: Raw %.6f%%, SoftClip %.6f%%, gain %+.6f pp\n', ...
        cfg.dataset,splits(k).seed,100*raw.OA,100*purified.OA,100*result.OA_gain);
    % Persist progress after every completed pair.
    names={'seed','Raw_OA','Raw_AA','Raw_Kappa','SPPR_OA','SPPR_AA','SPPR_Kappa', ...
        'OA_gain','Raw_dimension','SPPR_dimension'};
    summary=array2table(records(1:k,:),'VariableNames',names);
    writetable(summary,fullfile(run_root,'trials.csv'));
end
aggregate=array2table([mean(records(:,2:8),1);std(records(:,2:8),0,1)], ...
    'VariableNames',summary.Properties.VariableNames(2:8),'RowNames',{'mean','sample_std'});
writetable(aggregate,fullfile(run_root,'summary.csv'),'WriteRowNames',true);
fprintf('Saved unique SoftClip validation results to %s\n',run_root);
end
