function result = run_demo()
%RUN_DEMO Small synthetic paired example; no downloaded data or MEX needed.
setup(); saved=rng; cleanup=onCleanup(@()rng(saved)); %#ok<NASGU>
rng(17,'twister'); H=18; W=18; B=5;
gt=ones(H,W); gt(:,10:end)=2; X=rand(H,W,B)*0.15;
for b=1:B, X(:,:,b)=X(:,:,b)+0.35*(gt==2)*(b/B); end
cfg=paper_config('Indian'); cfg.window=3; cfg.dimension=2; cfg.train_ratio=0.2;
cfg.minimum_train=1; cfg.batch_size=23; cfg.seeds=17; cfg.pca_dimension=0;
cfg.split_source='generated'; cfg.segmentation_source='recompute';
cfg.clcr_diagnostics=true;
X=preprocess_cube(X,cfg); state=sppr_prepare(X,gt);
split=make_split(gt,cfg,17); result=run_pipeline(X,gt,split,cfg,state);
result.reproduction_status='synthetic_demo_not_benchmark';
result.segmentation.note='Synthetic region map; not ERS and not a benchmark evaluation.';
fprintf('Synthetic demo: Raw OA %.2f%%, SPPR OA %.2f%%\n', ...
    100*result.Raw_TDLPP.metrics.OA,100*result.SPPR_TDLPP.metrics.OA);
end
