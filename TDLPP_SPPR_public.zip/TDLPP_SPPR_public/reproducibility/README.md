# Frozen screenshot inputs

`splits/`: byte-identical saved valid-relative splits, seeds 1001–1010; the loader converts indices to original-scene linear positions without changing order.

`ers_cache/`: byte-identical pseudo-label maps, candidate membership lists and metadata used by the original 11×11 experiment. No cube spectra, training patches or predictions are stored here. Historical metadata paths are provenance, not runtime dependencies.

Dataset files remain external. Input fingerprints are checked for the default frozen run. These new validation splits are not claimed to be the manuscript's original splits. MATLAB classifier/toolbox behavior and the pre-update solver are deliberately retained.
