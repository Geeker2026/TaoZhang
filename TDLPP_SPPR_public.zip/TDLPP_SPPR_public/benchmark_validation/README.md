# Current unique-candidate SoftClip validation

These files describe the 2026-10-02 fresh refit of the restored screenshot method, using ten frozen splits per dataset and 11x11 patches. See REPORT.zh-CN.md and SUMMARY.csv. PAIRED_GAIN_SUMMARY.csv reports percentage-point differences and paired 95% t intervals. INDEPENDENT_RESULTS.csv contains the independently checked new outputs; local absolute paths identify audit artifacts rather than runtime dependencies.

The previous independent-selection benchmark is archived under ../historical_independent_v1/benchmark_validation/. These new saved splits do not establish reproduction of the unpublished original manuscript splits or Table 10.

Audit artifact identifiers beginning with `local-audit/` refer to the authors' local validation records. They are not files bundled in this repository or runtime dependencies. Their original local absolute paths were replaced for publication; numerical results and source fingerprints were retained.
