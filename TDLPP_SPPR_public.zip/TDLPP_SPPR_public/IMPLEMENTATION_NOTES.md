# TDLPP implementation details and interpretation limits

These notes describe the current implementation. They do not change the solver or establish theoretical guarantees beyond the supplied evidence.

## Initialization

For a mode projection `U_k` with `d_k` rows and `m_k` columns, initialization is the first `d_k` rows of the `m_k`-by-`m_k` identity matrix:

\[
U_k^{(0)}=\left[I_{d_k}\;\;\mathbf{0}_{d_k\times(m_k-d_k)}\right]
\in\mathbb{R}^{d_k\times m_k}.
\]

Here `I_{d_k}` is square. In MATLAB this is `eye(d_k,m_k)`. The core uses `eye(1,I1)`, `eye(1,I2)` and `eye(dim,I3)` for the two spatial modes and the spectral mode, respectively. This is deterministic truncated identity initialization, independent of the data. Its rows are orthonormal in the Euclidean sense; this does not assert a scatter-weighted normalization constraint. It initially selects the first mode coordinates, rather than the spatial center of a patch. Subsequent mode updates learn the projections. HongHu PCA preprocessing is a separate step.

## Generalized eigenvalue selection

The core solves `eig(S_B,S_W)`, sorts eigenvalues in descending order, and retains those satisfying the absolute test `lambda > eps`, up to the requested dimension. It does not apply a scale-aware effective-rank threshold or ridge regularization. `model.effective_dimension` records the number of retained rows, not the number of statistically or numerically significant discriminant directions.

With both spatial output dimensions equal to one, the spectral between-class scatter has rank at most `C-1` for `C` classes. The requested spectral dimensions for Indian Pines (50), Salinas (50) and Houston (15) exceed their bounds of 15, 15 and 14. Floating-point eigenvalues near zero can pass the absolute `eps` test and enter the output. The retained dimensions must not be interpreted as an equal number of exact nonzero between-class directions. Changing this numerical rule can change features, nearest-neighbor predictions and benchmark results and requires renewed validation.

A generalized-eigenvector update with a scatter normalization constraint should not be described as automatically solving the unconstrained multidimensional trace-ratio objective. The manuscript's optimization formulation and guarantees must be checked against the constraints actually imposed by the update; numerical reproduction alone does not prove this equivalence.

## Objective history and iteration counts

`model.objective` stores `J=C_W/C_B` before each complete sweep of updates to `U1`, `U2` and `U3`. The first sample is the initialized objective, conventionally plotted at iteration zero. A tolerance stop returns after `model.iterations-1` completed sweeps; `model.completed_sweeps` reports this count directly. At the maximum of 50 sweeps, the last recorded sample precedes the final sweep, so the returned projections do not have an additional post-update objective sample in this history.

For the additional ten Raw-TDLPP splits on each dataset, all 40 runs met the absolute objective-change threshold of 0.005 before the maximum of 50 sweeps. Completed-sweep means and sample standard deviations were 19.30 ± 2.83 (Indian Pines), 13.10 ± 2.88 (Salinas), 6.10 ± 0.74 (HongHu), and 10.10 ± 1.91 (Houston). These are empirical stopping statistics for the specified splits. The observed histories are not strictly monotone in every run; neither global optimality nor convergence to a stationary point is inferred from reaching the stopping threshold.

## Experimental scope

The current validation comprises Raw-TDLPP and SPPR-TDLPP on four datasets, ten additional fixed splits per dataset and an 11-by-11 window. It does not recreate the unpublished original manuscript splits or reproduce every method, window, CLCR figure or Table 10 value. Whole-scene normalization/PCA, frozen scene segmentation and separate training/test partition centering must be disclosed when interpreting this random-pixel evaluation.
