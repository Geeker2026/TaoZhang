function hash = file_sha256(file)
%FILE_SHA256 Stream file fingerprints without retaining full datasets.
fid=fopen(file,'rb'); assert(fid>0,'Missing fingerprint input: %s',file);
cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while true
    bytes=fread(fid,1024*1024,'*uint8'); if isempty(bytes), break; end
    md.update(typecast(bytes,'int8'));
end
hash=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2).',1,[]));
end
