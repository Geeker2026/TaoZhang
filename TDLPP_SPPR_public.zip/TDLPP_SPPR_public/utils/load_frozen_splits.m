function splits = load_frozen_splits(gt,cfg,file)
%LOAD_FROZEN_SPLITS Convert saved valid-relative indices without resampling.
if nargin<3 || isempty(file), file=cfg.split_file; end
a=load(file);
if isfield(a,'split_info')
    valid=double(a.split_info.valid_linear_idx(:));
    assert(isequal(valid,double(find(gt>0))),'Frozen valid-index order mismatch.');
    old=a.split_info.splits;
    splits=repmat(struct('seed',0,'train_linear',[],'test_linear',[], ...
        'provenance',a.split_info.provenance),numel(cfg.seeds),1);
    for k=1:numel(cfg.seeds)
        i=find([old.seed]==cfg.seeds(k)); assert(isscalar(i),'Missing/duplicate seed.');
        splits(k).seed=old(i).seed;
        splits(k).train_linear=valid(double(old(i).train_idx(:)));
        splits(k).test_linear=valid(double(old(i).test_idx(:)));
    end
else
    assert(isfield(a,'splits') && all(isfield(a.splits, ...
        {'seed','train_linear','test_linear','provenance'})),'Invalid external splits.');
    order=arrayfun(@(s)find([a.splits.seed]==s,1),cfg.seeds);
    assert(numel(order)==numel(cfg.seeds),'Missing external split.');
    splits=a.splits(order);
end
end
