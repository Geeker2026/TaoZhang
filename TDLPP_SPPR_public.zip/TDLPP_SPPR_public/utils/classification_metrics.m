function metrics = classification_metrics(predicted,truth,classes)
%CLASSIFICATION_METRICS OA, AA and kappa in [0,1], arbitrary class IDs.
predicted=predicted(:); truth=truth(:);
assert(numel(predicted)==numel(truth) && ~isempty(truth));
if nargin<3, classes=unique(truth); end
[ok1,a]=ismember(predicted,classes); [ok2,b]=ismember(truth,classes);
assert(all(ok1 & ok2),'Labels outside the specified class set.');
C=numel(classes); CM=accumarray([b,a],1,[C,C]); total=sum(CM,'all');
counts=sum(CM,2); acc=diag(CM)./counts; oa=trace(CM)/total;
pe=sum(sum(CM,1)'.*counts)/total^2;
if pe==1, kappa=NaN; else, kappa=(oa-pe)/(1-pe); end
metrics=struct('OA',oa,'AA',mean(acc(counts>0)),'Kappa',kappa, ...
    'classes',classes(:),'per_class_accuracy',acc,'confusion',CM, ...
    'unit','proportion','confusion_rows','true_labels');
end
