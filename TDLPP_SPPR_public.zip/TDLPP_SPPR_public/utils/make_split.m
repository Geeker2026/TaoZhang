function split = make_split(gt,cfg,seed)
%MAKE_SPLIT New validation splits, not the unpublished manuscript indices.
saved=rng; cleanup=onCleanup(@()rng(saved)); %#ok<NASGU>
rng(seed,'twister'); valid=find(gt>0); y=gt(valid); classes=unique(y);
train=[]; test=[];
for k=1:numel(classes)
    idx=find(y==classes(k)); order=idx(randperm(numel(idx)));
    if isempty(cfg.train_per_class)
        nt=max(cfg.minimum_train,floor(numel(idx)*cfg.train_ratio)); nv=numel(idx)-nt;
    else
        nt=cfg.train_per_class; nv=cfg.test_per_class;
    end
    assert(nt>=1 && nv>=1 && nt+nv<=numel(idx), ...
        'Class %g has insufficient samples for requested partition.',classes(k));
    train=[train;order(1:nt)]; test=[test;order(nt+1:nt+nv)]; %#ok<AGROW>
end
split=struct('seed',seed,'train_linear',valid(train),'test_linear',valid(sort(test)), ...
    'provenance','new_public_validation_split_not_paper_original');
end
