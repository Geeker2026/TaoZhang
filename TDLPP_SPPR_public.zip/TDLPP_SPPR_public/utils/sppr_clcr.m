function diagnostic = sppr_clcr(gt,row,col,window,info)
%SPPR_CLCR POST-HOC hard-assignment diagnostic, never used by reconstruction.
% Unlabeled pixels (0) remain in the denominator, matching manuscript Eq.18.
[labels,~,~]=extract_patch(gt,row,col,window); after=labels;
assigned=info.source_linear>0; after(assigned)=gt(info.source_linear(assigned));
center=gt(row,col); assert(center>0,'CLCR center must have a ground-truth label.');
before=mean(labels(:)==center); value=mean(after(:)==center);
diagnostic=struct('before',before,'after_hard_assignment',value, ...
    'change',value-before,'unlabeled_source_count',nnz(assigned & after==0), ...
    'scope','hard_assignment_before_interpolation');
end
