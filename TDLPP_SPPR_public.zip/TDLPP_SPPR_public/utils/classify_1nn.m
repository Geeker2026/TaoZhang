function predicted = classify_1nn(training,labels,testing,batch_size)
%CLASSIFY_1NN Euclidean 1-NN, deterministic first-training-sample tie break.
if nargin<4, batch_size=250; end
labels=labels(:); assert(size(training,1)==numel(labels));
assert(all(isfinite(training(:))) && all(isfinite(testing(:))));
predicted=zeros(size(testing,1),1,'like',labels);
for first=1:batch_size:size(testing,1)
    last=min(first+batch_size-1,size(testing,1)); z=testing(first:last,:);
    D=max(0,sum(z.^2,2)+sum(training.^2,2)'-2*z*training');
    [~,index]=min(D,[],2); predicted(first:last)=labels(index);
end
end
