function [scores,basis] = release_pca(Y,dimension,center_projection)
%RELEASE_PCA Base-MATLAB covariance PCA, no external PCA or mapminmax.
if nargin<3, center_projection=true; end
Y=double(Y); mu=mean(Y,1); Z=Y-mu;
[V,D]=eig(Z'*Z,'vector'); [~,order]=sort(real(D),'descend');
basis=real(V(:,order(1:min(dimension,size(Y,2)))));
% Fix otherwise arbitrary signs for reproducible grayscale segmentation.
for k=1:size(basis,2)
    [~,j]=max(abs(basis(:,k))); if basis(j,k)<0, basis(:,k)=-basis(:,k); end
end
if center_projection, scores=Z*basis; else, scores=Y*basis; end
end
