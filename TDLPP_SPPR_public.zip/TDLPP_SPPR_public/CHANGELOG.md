# Version 2 — unique-candidate SoftClip (2026-10-02)

- Restored screenshot candidate uniqueness, row-major order, exhaustion handling and single-precision interpolation.
- Ported frozen graph/core kernels with function-name changes only; retained original preprocessing/PCA and classifier behavior.
- Bundled byte-identical fixed splits and ERS states with provenance; default seeds 1001–1010 and minimum training count ten.
- Added fixed-input comparison and fresh full-refit acceptance; see VALIDATION.md for the actual completion status.
- Updated method documentation and Eqs. (15)–(16) replacement draft. Historical v1 benchmark tables remain explicitly labeled.

## Publication documentation check (2026-10-02)

- Corrected the manuscript-version comparison: the latest checked PDF already contains sequential SPPR selection without replacement and candidate-exhaustion handling.
- Documented deterministic truncated identity initialization, numerical rank limitations, objective-history timing, input-file hash requirements and tested platform/toolbox dependencies.
- Replaced local data paths in the Chinese quick start with package-relative examples. Solver code, fixed inputs and numerical result tables were unchanged.
- Authors' code licensing, legacy PCA redistribution permission, external data preparation and citation metadata remain publication tasks; these documentation edits do not mark the package publication-ready.

# Version 1

- Created an independent release folder without changing the working project.
- Unified SPPR as independent reusable candidate selection plus adaptive interpolation, following Eqs. (15)-(17) in the supplied PDF.
- Kept candidates in the original scene, specified symmetric-border behavior, and used an equivalent logarithmic score to avoid overflow.
- Separated post-hoc hard-assignment CLCR from mixed-spectrum reconstruction.
- Implemented tensor Frobenius distances without calling 2-D `norm(...,'fro')` on 3-D arrays.
- Supported arbitrary class IDs consistently in graph construction, class means and evaluation.
- Recorded objective history after complete TDLPP sweeps; disclosed eigenvalue filtering and effective output dimension.
- Replaced external PCA/scaling/metric helpers with base-MATLAB implementations. PCA signs are fixed, which can alter ERS rounding/tie behavior relative to historical helpers.
- Used double precision in the public preprocessing and solver rather than the working runner's single-precision patch accumulation. Numerical identity to historical outputs is not claimed.
- Exposed centering, HongHu PCA and training-count choices explicitly; generated splits are new validations, not manuscript-original splits.
- Preserved ERS source/notices and added a portable build entry point.
- Omitted comparison methods, exploratory variants, local profiles, historical results, reports, caches and datasets.
