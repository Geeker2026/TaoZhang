function report = run_tests(include_ers)
%RUN_TESTS Validate the current unique-candidate SoftClip version.
if nargin<1, include_ers=false; end
report=run_frozen_tests(include_ers);
end
