function report = test_local_data(data_root,output_root)
%TEST_LOCAL_DATA Small real-data I/O smoke test, not a paper accuracy run.
% Indian Pines, two new splits, four training and two testing centers per
% class; window=3, PCA=6, dimension=2. No datasets are bundled with release.
setup(); cfg=paper_config('Indian'); cfg.window=3; cfg.dimension=2;
cfg.pca_dimension=6; cfg.batch_size=13;
cfg.split_source='generated'; cfg.segmentation_source='recompute'; cfg.seeds=[201 202];
a=load(fullfile(data_root,cfg.folder,cfg.gt_file),cfg.gt_variable);
gt=a.(cfg.gt_variable); cfg.train_per_class=4; cfg.test_per_class=2;
splits=[make_split(gt,cfg,201),make_split(gt,cfg,202)];
if ~exist(output_root,'dir'), mkdir(output_root); end
split_file=fullfile(output_root,'smoke_splits.mat');
assert(~exist(split_file,'file'),'Use a fresh smoke output directory.');
save(split_file,'splits');
summary=run_experiment('Indian',data_root,output_root,cfg,split_file);
assert(height(summary)==2 && all(isfinite(summary{:,2:8}),'all'));
assert(all(summary.Raw_OA>=0 & summary.Raw_OA<=1));
assert(all(summary.SPPR_OA>=0 & summary.SPPR_OA<=1));
assert(max(abs(summary.OA_gain-(summary.SPPR_OA-summary.Raw_OA)))<1e-12);
report=struct('passed',true,'dataset','Indian Pines','trials',2, ...
    'train_per_class',4,'test_per_class',2,'window',3,'PCA',6, ...
    'dimension',2,'paper_configuration',false,'summary',summary);
fprintf('PASS: real Indian Pines segmentation, paired pipeline and result export.\n');
end
