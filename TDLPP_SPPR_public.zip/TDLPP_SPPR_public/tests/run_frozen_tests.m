function report = run_frozen_tests(include_ers)
%RUN_FROZEN_TESTS Invariants of unique-candidate SoftClip and frozen defaults.
if nargin<1, include_ers=false; end
setup(); saved=rng; cleanup=onCleanup(@()rng(saved)); %#ok<NASGU>
rng(91,'twister'); checks={}; X=single(rand(7,7,4));
map=2*ones(7); map(3,3)=1; map(1,1)=1;
[z,info]=sppr_reconstruct(X,sppr_prepare(X,map),3,3,3);
raw=extract_patch(X,3,3,3); assigned=info.source_linear>0;
assert(nnz(assigned)==1 && info.unassigned_count==7);
assert(numel(unique(info.source_linear(assigned)))==nnz(assigned));
assert(isequal(z(repmat(~assigned,1,1,4)),raw(repmat(~assigned,1,1,4))));
for i=1:3
    for j=1:3
        original=double(reshape(raw(i,j,:),1,[]));
        modified=double(reshape(z(i,j,:),1,[]));
        center=double(reshape(raw(2,2,:),1,[]));
        assert(norm(modified-original)<=norm(original-center)+2e-7);
    end
end
checks{end+1}='candidate_uniqueness_exhaustion_and_softclip_bound';
map(1,1)=2; state=sppr_prepare(X,map); [z,info]=sppr_reconstruct(X,state,3,3,3);
assert(isequal(z,raw) && info.unassigned_count==8);
[z,info]=sppr_reconstruct(X,sppr_prepare(X,ones(7)),1,1,5);
assert(isequal(z,extract_patch(X,1,1,5)) && ~any(info.mask(:)));
checks{end+1}='empty_pool_and_homogeneous_identity';
[~,rr,cc]=extract_patch(X,1,1,5); assert(isequal(rr,[2 1 1 2 3]) && isequal(rr,cc));
cfg=paper_config('Indian'); assert(isequal(cfg.seeds,1001:1010) && cfg.minimum_train==10);
assert(cfg.window==11 && strcmp(cfg.split_source,'frozen'));
assert(strcmp(cfg.segmentation_source,'frozen') && strcmp(cfg.classifier,'frozen_fitcknn'));
checks{end+1}='padding_and_frozen_defaults';
blocks=arrayfun(@(~)single(rand(3,3,4)),1:20,'UniformOutput',false);
labels=[10*ones(10,1);30*ones(10,1)]; [W,B,t1,t2]=tdlpp_graph(blocks,labels);
assert(isequal(W,W') && isequal(B,B') && ~any(diag(W)) && ~any(W(1:10,11:20),'all'));
assert(t1>0 && t2>0); cfg.dimension=2; model=tdlpp_fit(blocks,labels,cfg);
assert(isequal(model.classes,[10;30]) && model.iterations<=50);
assert(strcmp(model.history_position,'before_sweep_frozen'));
assert(all(isfinite(model.train_features(:))) && model.ridge==0);
checks{end+1}='frozen_graph_core_and_history';
metrics=classification_metrics([10;10;30;30],[10;30;30;30]);
assert(abs(metrics.OA-0.75)<1e-12 && abs(metrics.AA-5/6)<1e-12);
assert(abs(metrics.Kappa-0.5)<1e-12); checks{end+1}='metric_oracle';
demo=run_demo(); assert(all(isfinite([demo.Raw_TDLPP.metrics.OA,demo.SPPR_TDLPP.metrics.OA])));
checks{end+1}='paired_synthetic_pipeline';
if include_ers
    cfg=paper_config('Indian'); cfg.segmentation_source='recompute'; cfg.target_area=50;
    cube=single(rand(18,18,5)); [state,meta]=sppr_segment(cube,cfg);
    assert(meta.K==6 && numel(state.ids)==6 && ~meta.ground_truth_used);
    checks{end+1}='optional_recomputed_ers_mex';
end
report=struct('passed',true,'checks',{checks},'matlab_version',version, ...
    'ers_tested',include_ers,'full_benchmarks_rerun',false);
fprintf('PASS: %d unique SoftClip release checks.\n',numel(checks));
end
