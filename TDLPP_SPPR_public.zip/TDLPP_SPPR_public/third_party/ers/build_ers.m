function build_ers()
%BUILD_ERS Build unmodified ERS source with MATLAB's configured C++ compiler.
here=fileparts(mfilename('fullpath')); src=fullfile(here,'source');
names={'mex_ers.cpp','MERCCInput.cpp','MERCOutput.cpp', ...
    'MERCDisjointSet.cpp','MERCFunctions.cpp','MERCLazyGreedy.cpp'};
files=cellfun(@(name)fullfile(src,name),names,'UniformOutput',false);
mex('-R2017b',['-I' src],'-outdir',here,'-output','mex_ers',files{:});
fprintf('Built %s\n',fullfile(here,['mex_ers.' mexext]));
end
