# Third-party notices

## Entropy Rate Superpixel Segmentation (ERS)

Copyright 2011, Ming-Yu Liu. Authors: Ming-Yu Liu, Oncel Tuzel, Srikumar Ramalingam and Rama Chellappa. Reference: *Entropy Rate Superpixel Segmentation*, CVPR, 2011.

`third_party/ers/source/` and `third_party/ers/UPSTREAM_README.txt` retain the local upstream source and notices unchanged. The license permits use, copying, modification and distribution for non-commercial purposes, with the copyright and permission notices retained. The complete terms are in the upstream README and source headers. Those terms also apply to the bundled ERS implementation; this package does not relicense it.

The bundled `mex_ers.mexw64` was copied from the working project's ERS dependency. The available upstream source was recovered from the adjacent legacy code directory. Its build correspondence to the precompiled binary is not independently established; `build_ers.m` allows building from the included source. The mathematical test suite exercises the supplied binary, but does not claim binary/source identity.

## Frozen PCA helpers

`third_party/legacy_pca/frozen_pca_basis.m` and `frozen_pca_svd.m` are copied from the working project's Deng Cai PCA/mySVD helpers. Original author/version comments are retained; only function/helper names were changed to avoid path collisions. Source paths and fingerprints are recorded in `reproducibility/KERNEL_AND_INPUT_PROVENANCE.json`. This packaging does not assign a new license to those upstream helpers. The scaling and metric implementations remain dedicated helpers.

## Authors' project code

This packaging task does not assign a license on behalf of the authors. Select and add an appropriate license for the authors' MATLAB files when publishing; do not remove or replace the separate ERS non-commercial license. Public availability alone does not grant a project-wide reuse license.
