> Historical v1 independent-selection benchmark (2026-10-01). These results do not belong to the current unique-candidate SoftClip v2. / 历史独立候选版结果，不属于当前互斥 SoftClip 版。

# Unified public-release validation

Independent re-evaluation of saved predictions using original dataset ground truth.

**All four datasets: 40 paired trials / 80 models verified.**

| Dataset | Trials | Raw OA (%) | SPPR OA (%) | SPPR gain (pp) | Positive trials | Paper Raw / SPPR OA (%) |
|---|---:|---:|---:|---:|---:|---|
| Indian | 10 | 95.4115 | 95.5326 | +0.1211 | 4/10 | 95.74 / 97.65 |
| Salinas | 10 | 97.8388 | 96.5193 | -1.3195 | 0/10 | 97.53 / 98.06 |
| HongHu | 10 | 93.9818 | 92.5894 | -1.3924 | 0/10 | 94.15 / 94.68 |
| Houston | 10 | 96.0067 | 95.8261 | -0.1806 | 4/10 | 96.65 / 96.79 |

Detailed OA/AA/kappa means, sample standard deviations and paper differences are in the comparison CSV. Paired gains include positive/negative counts and unadjusted t-based 95% intervals.

## Interpretation limits

- New seeds 1-10 are validation splits, not the unavailable original manuscript splits.
- Configuration is the public release default: floor-per-class sampling with minimum 1; partition-wise centering; HongHu full-scene PCA=80; ridge=0.
- Ground truth is used for supervised training, splitting and post-hoc evaluation, not SPPR candidate selection.
- CLCR describes hard candidate assignment before interpolation; unlabelled sources limit interpretation.
- Paper reconstructed-arm AA/kappa are not reported in Table 10, so those paper comparisons remain unavailable.
- Confidence intervals describe within-protocol paired differences. Different splits and undocumented preprocessing prevent a formal significance comparison against paper means.
- Random-pixel splits may have overlapping spatial patches. Runtime is this implementation on this machine, not a reproduction of the paper runtime table.

## Publication assessment

The code is executable and its saved metrics are internally verified, but this validation does not reproduce the manuscript's uniformly positive SPPR gains. Negative mean gains occur on: Salinas, HongHu, Houston.

Do not present this implementation as a verified reproduction of the manuscript tables. Confirm the implementation used to generate the original tables, clarify splits/preprocessing, and examine the nonzero-eigenvalue/dimension issue in METHOD_ALIGNMENT_NOTES.md before aligning manuscript claims and a formal release.
