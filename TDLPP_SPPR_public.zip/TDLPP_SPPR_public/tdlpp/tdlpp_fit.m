function model = tdlpp_fit(blocks,labels,cfg)
%TDLPP_FIT Frozen eigensolver, pair order and pre-update stopping behavior.
assert(cfg.ridge==0 && cfg.max_iterations==50 && cfg.tolerance==0.005, ...
    'Frozen core requires ridge=0, max_iterations=50, tolerance=0.005.');
[W,B,t1,t2]=tdlpp_graph(blocks,labels,cfg.t1,cfg.t2);
[classes,~,group]=unique(labels(:),'sorted');
[U1,U2,U3,J,Ci,Cb]=frozen_tdlpp_core(blocks,group,cfg.dimension,W,B);
written=(J~=0)|(Ci~=0)|(Cb~=0); t=find(written,1,'last');
assert(~isempty(t) && all(written(1:t)) && t<=50,'Invalid frozen history.');
reason='max_iterations'; updates=t;
if t>1 && abs(J(t)-J(t-1))<cfg.tolerance
    reason='objective_tolerance'; updates=t-1;
end
model=struct('U1',U1,'U2',U2,'U3',U3,'t1',t1,'t2',t2, ...
    'classes',classes,'ridge',0,'objective',J(1:t),'within',Ci(1:t), ...
    'between',Cb(1:t),'iterations',t,'completed_sweeps',updates, ...
    'effective_dimension',size(U3,1),'requested_dimension',cfg.dimension, ...
    'stop_reason',reason,'history_position','before_sweep_frozen', ...
    'solver','frozen_tdlpp_core');
model.train_features=tdlpp_project(blocks,model);
end
