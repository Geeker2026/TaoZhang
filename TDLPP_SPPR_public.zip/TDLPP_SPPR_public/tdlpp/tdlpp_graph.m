function [W,B,t1,t2] = tdlpp_graph(blocks,labels,t1,t2)
%TDLPP_GRAPH Preserve frozen distances and class-mean accumulation.
if nargin<3, t1=[]; end
if nargin<4, t2=[]; end
[W,B,t1,t2]=frozen_tdlpp_graph(blocks,labels,t1,t2);
end
