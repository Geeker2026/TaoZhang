function result = run_pipeline(X,gt,split,cfg,state)
%RUN_PIPELINE Paired Raw+TDLPP and frozen unique SoftClip+TDLPP.
% Test patches are streamed; only their feature matrix is retained.
if nargin<5, state=[]; end
assert(isequal(size(gt),size(X,[1 2])) && all(isfinite(X(:))));
assert(all(gt(:)>=0) && all(gt(:)==floor(gt(:))),'GT must contain nonnegative integer labels.');
train=double(split.train_linear(:)); test=double(split.test_linear(:));
validate_indices(train,numel(gt)); validate_indices(test,numel(gt));
assert(isempty(intersect(train,test)),'Training and testing centers overlap.');
assert(all(gt([train;test])>0),'Split contains unlabeled centers.');
assert(all(ismember(unique(gt(test)),unique(gt(train)))),'Test class absent from training.');
validateattributes(cfg.batch_size,{'numeric'},{'scalar','integer','positive'});
assert(ismember(cfg.centering,{'partition','training'}),'Unknown centering mode.');
assert(cfg.ridge>=0 && cfg.tolerance>=0 && cfg.max_iterations>=1);
% Caller provides the PREPROCESSED cube so external pseudo-maps cannot
% silently be applied to a different PCA/normalization representation.
segmentation=struct('provided_pseudo_map',~isempty(state),'ground_truth_used',false);
timer=tic;
if isempty(state), [state,segmentation]=sppr_segment(X,cfg); end
assert(isequal(size(state.pseudo_map),size(gt)) && state.height==size(X,1) && state.width==size(X,2));
segmentation.seconds=toc(timer);
[rows,cols]=ind2sub(size(gt),train); training_labels=double(gt(train)); truth=double(gt(test));
variants={'Raw_TDLPP','SPPR_TDLPP'};
result=struct('version',cfg.version,'config',cfg,'split',split, ...
    'segmentation',segmentation,'sppr_algorithm',state.algorithm, ...
    'reproduction_status','frozen_screenshot_protocol_not_paper_original_splits');
for arm=1:2
    timer=tic; blocks=cell(numel(train),1);
    for k=1:numel(train)
        if arm==1, blocks{k}=extract_patch(X,rows(k),cols(k),cfg.window);
        else, blocks{k}=sppr_reconstruct(X,state,rows(k),cols(k),cfg.window); end
    end
    train_mean=zeros(size(blocks{1}),'single');
    for k=1:numel(blocks), train_mean=train_mean+single(blocks{k}); end
    train_mean=train_mean/numel(blocks);
    for k=1:numel(blocks), blocks{k}=single(blocks{k})-train_mean; end
    model=tdlpp_fit(blocks,training_labels,cfg);
    train_seconds=toc(timer); clear blocks
    timer=tic; [features,clcr]=test_features(X,gt,test,cfg,state,model,arm==2,train_mean);
    if strcmp(cfg.classifier,'frozen_fitcknn')
        classifier=fitcknn(model.train_features,training_labels(:), ...
            'NumNeighbors',1,'Distance','euclidean','Standardize',false);
        prediction=predict(classifier,features);
    else
        assert(strcmp(cfg.classifier,'base_1nn'),'Unknown classifier.');
        prediction=classify_1nn(model.train_features,training_labels,features,cfg.batch_size);
    end
    output=struct('model',model,'prediction',prediction,'truth',truth, ...
        'metrics',classification_metrics(prediction,truth,unique(training_labels)), ...
        'train_seconds',train_seconds,'test_seconds',toc(timer),'clcr',clcr);
    result.(variants{arm})=output;
end
result.OA_gain=result.SPPR_TDLPP.metrics.OA-result.Raw_TDLPP.metrics.OA;
end
function [features,diagnostics]=test_features(X,gt,indices,cfg,state,model,purify,train_mean)
[rows,cols]=ind2sub(size(gt),indices); n=numel(indices);
features=zeros(n,size(model.train_features,2)); total=zeros(size(train_mean),'single');
diagnostics=[];
if purify && cfg.clcr_diagnostics, diagnostics=zeros(n,4); end
for first=1:cfg.batch_size:n
    last=min(n,first+cfg.batch_size-1); blocks=cell(last-first+1,1);
    for k=first:last
        if purify
            [patch,info]=sppr_reconstruct(X,state,rows(k),cols(k),cfg.window);
            if cfg.clcr_diagnostics
                % Ground truth is read ONLY after reconstruction is complete.
                d=sppr_clcr(gt,rows(k),cols(k),cfg.window,info);
                diagnostics(k,:)=[d.before,d.after_hard_assignment,d.change,d.unlabeled_source_count];
            end
        else
            patch=extract_patch(X,rows(k),cols(k),cfg.window);
        end
        total=total+single(patch); blocks{k-first+1}=patch;
    end
    features(first:last,:)=tdlpp_project(blocks,model);
end
if strcmp(cfg.centering,'partition'), offset=total/n; else, offset=train_mean; end
features=features-tdlpp_project({offset},model);
end
function validate_indices(indices,count)
assert(~isempty(indices) && all(indices>=1 & indices<=count & indices==floor(indices)), ...
    'Split must contain original-scene linear indices.');
assert(numel(unique(indices))==numel(indices),'Duplicate split indices.');
end
