# TDLPP + SPPR: MATLAB research implementation

This package implements row-major greedy candidate assignment **without reuse**, followed by SoftClip interpolation. The default profile is `formal_soft_clip_10split`, using saved seeds 1001–1010, 11×11 windows, at least ten training samples per class for proportional sampling, and frozen ERS partitions.

The manuscript `SGTDLPP_202603 (1).pdf` checked on 2026-10-02 already describes sequential selection without replacement and retention of the original spectrum upon candidate exhaustion in Eqs. (15)–(16), consistent with this implementation. `METHOD_REVISION.zh-CN.md` retains an earlier draft for older manuscript versions and records implementation details. The archived independent-selection v1 results in `historical_independent_v1/benchmark_validation/` do not describe this version.

The package was validated with MATLAB R2023b on Windows. The default classifier, synthetic demo and `run_tests(false)` require Statistics and Machine Learning Toolbox; the test suite includes the synthetic pipeline. The `false` argument skips ERS, rather than all external toolbox dependencies.

```matlab
setup;
report = run_tests(false);
result = run_demo();
cfg = paper_config('Indian');
data_root = fullfile(pwd, 'data'); % place externally obtained datasets here
output_root = fullfile(pwd, 'output');
summary = run_experiment('Indian', data_root, output_root, cfg);
```

Supported keys: Indian, Salinas, HongHu, Houston. Run from the package directory after placing the external datasets as described in `data/README.md`. The default run loads the bundled frozen splits and pseudo-maps and requires dataset files whose SHA-256 hashes match `reproducibility/INPUT_MANIFEST.json`. Array-equivalent files saved with different MAT-file metadata can fail this byte-level check. Dataset layout alone does not ensure that a downloaded file matches the frozen input. A fresh output folder contains configuration, fingerprints, splits, newly fitted models, predictions and metrics. CSV metrics use proportions. For one saved split, set `cfg.seeds=1001`.

Spectral dimensions are 50, 50, 20 and 15, respectively. HongHu retains the original full-scene 80-dimensional PCA. The original PCA helpers, single-precision preprocessing/partition means, frozen graph accumulation, generalized eigensolver and pre-update stopping checks are retained. Training and test partitions are centered separately. Default classification uses the original `fitcknn` settings (Euclidean 1-NN, no standardization), requiring Statistics and Machine Learning Toolbox. Tensor Toolbox and a GPU are not required. Cached maps avoid a segmentation dependency for the default benchmark; recomputation and the optional MEX check require ERS.

Projection initialization is deterministic: `U1=eye(1,I1)`, `U2=eye(1,I2)`, and `U3=eye(dim,I3)`. Each matrix consists of the first retained rows of the square identity of its input mode; the initialization is independent of the data. PCA preprocessing, where used, is separate from initialization. `IMPLEMENTATION_NOTES.md` explains the initialization dimensions, numerical eigenvalue selection, objective-history timing and theoretical interpretation limits.

Each candidate may be used only once within a patch. Assignment visits heterogeneous positions in row-major order and minimizes the exact frozen spatial/spectral score over unused candidates. Exhaustion retains remaining original spectra. Ties follow original-scene column-major index order. SoftClip bounds the correction using the original heterogeneous proportion and distance to the center. This is deterministic greedy assignment, not globally optimal matching. Ground truth is absent from reconstruction.

For optional post-hoc hard-assignment CLCR, set `cfg.clcr_diagnostics=true`; CLCR does not assign a true label to interpolated spectra. Generated splits or recomputed segmentation require explicit `split_source='generated'` / `segmentation_source='recompute'` and constitute a different experiment. A base-MATLAB classifier remains available as `cfg.classifier='base_1nn'`, without a claim of exact frozen classifier equivalence.

The optional `run_tests(true)` additionally exercises ERS. The bundled `mex_ers.mexw64` is a Windows binary; other platforms require building the supplied source with `build_ers` and a configured C++ compiler. Source-to-binary correspondence of the bundled binary has not been independently established.

The saved splits are additional local validations from 2026-09-30, not the unpublished original manuscript splits. Historical positive means do not establish reproduction of Table 10 or every individual split. Executed validation is described in `VALIDATION.md`; current result tables are in `benchmark_validation/`, with independent audit records in `validation_unique_softclip/`. See the Chinese README for protocol details, `reproducibility/` for provenance and `THIRD_PARTY_NOTICES.md` for preserved third-party notices.

No license for the authors' project code has yet been assigned. The ERS non-commercial terms remain separate, and redistribution permission for the legacy PCA helpers still needs to be documented before publication. Public access should not be described as an unrestricted project-wide reuse license.

Audit artifact identifiers beginning with `local-audit/` refer to the authors' local validation records. They are not files bundled in this repository or runtime dependencies. Their original local absolute paths were replaced for publication; numerical results and source fingerprints were retained.
