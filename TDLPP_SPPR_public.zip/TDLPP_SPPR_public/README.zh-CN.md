# TDLPP + SPPR：互斥候选 SoftClip 版

默认实现为 `formal_soft_clip_10split`：**按行贪心分配互斥候选 + SoftClip，自原图构造候选，候选耗尽则保留原光谱**。2026-10-02 核对的稿件 `SGTDLPP_202603 (1).pdf` 式（15）–（16）已经包含顺序无放回选择及候选耗尽回退，与本版 SPPR 实现一致。`METHOD_REVISION.zh-CN.md` 保留针对旧稿的修改草稿及实现说明，不能将旧稿差异当作本次 PDF 的差异。

这套固定方法的历史十组平均 OA 增益为 Indian +1.6238、Salinas +0.1280、HongHu +0.2500、Houston +0.4215 个百分点。新公开版的完整重训验收以 `VALIDATION.md` 为准；历史结果不当作新运行结果。`historical_independent_v1/benchmark_validation/` 保留的是此前独立候选 v1 的结果，不能引用为本版本结果。当前版本验收表放在 `benchmark_validation/`，逐组独立核验记录放在 `validation_unique_softclip/`。

## 运行

在本目录进入 MATLAB：

```matlab
setup;
report = run_tests(false);
result = run_demo();
cfg = paper_config('Indian');
data_root = fullfile(pwd, 'data'); % 按 data/README.md 放置外部数据
output_root = fullfile(pwd, 'output');
summary = run_experiment('Indian', data_root, output_root, cfg);
```

支持 Indian、Salinas、HongHu、Houston。`run_experiment` 默认读取包内已经保存的十组划分和 ERS 分区，不重新采样或分割。每次创建新输出目录，保存配置、输入指纹、划分、模型、预测和指标；每完成一组即更新 `trials.csv`。精度 CSV 使用0–1尺度，乘100后才是百分比或百分点。仅跑一组可设置 `cfg.seeds=1001`；不更改这组划分。

真实数据需从外部提供，组织方式见 `data/README.md`；缓存文件只有分区及候选索引，没有原始光谱、训练 patch 或预测。默认冻结协议还要求数据文件 SHA-256 与 `reproducibility/INPUT_MANIFEST.json` 完全一致；即使数组相同，重新保存 MAT 文件也可能改变文件哈希，因此仅符合文件名和变量名不能保证默认协议可运行。

## 默认协议

| 数据集 | 窗口 | 谱模维数 | 训练抽样 | 测试抽样 |
|---|---:|---:|---|---|
| Indian | 11×11 | 50 | 每类 floor(5%)，最低10 | 剩余有标签像素 |
| Salinas | 11×11 | 50 | 每类 floor(1%)，最低10 | 剩余有标签像素 |
| HongHu | 11×11 | 20 | 每类50 | 每类300 |
| Houston | 11×11 | 15 | 每类 floor(5%)，最低10 | 剩余有标签像素 |

保存的划分种子为1001–1010；它们是2026-09-30新增验证划分，不是已经确认的原稿原始十组。HongHu 使用原 PCA 实现做全图80维投影。归一化光谱、训练中心化和测试均值累加保留 single；训练和测试分区分别中心化。TDLPP 图权重、边遍历顺序、广义特征值选择和更新前停止检查采用原冻结内核。

初始化采用确定性的截断单位矩阵：`U1=eye(1,I1)`、`U2=eye(1,I2)`、`U3=eye(dim,I3)`，即各输入模式方形单位矩阵的前若干行。初始化不依赖数据；HongHu 的 PCA 预处理是独立步骤。维度、数值特征值筛选、目标历史和理论解释边界见 `IMPLEMENTATION_NOTES.md`。

## 重构规则

1. 以中心的超像素伪标签判定异质位置，从原图同伪标签像素中构造候选池，排除当前 patch 已保留的同质位置。
2. 按行从上到下、行内从左到右处理。评分保持 `d_spatial/exp(-d_spectral)`，并列时选最小原图线性索引；选中候选从当前 patch 的后续候选池中移除。
3. 若候选耗尽，余下位置保留原光谱。
4. 按旧版精度应用 `raw + alpha.*(hard-raw)`，其中 `alpha=min(1-rho, distance(raw,center)/(distance(hard,raw)+eps))`，rho来自原异质掩膜。

互斥集合仅在单个 patch 内生效，不跨训练/测试或不同 patch 共享。这是确定顺序的贪心分配，不保证互斥全局匹配最优。候选选择不接收真值。CLCR 可通过 `cfg.clcr_diagnostics=true` 启用，只评价插值前硬分配；它不能为混合光谱指定真实类别。

## 依赖与变体

为保持旧预测的分类器行为，默认使用 Statistics and Machine Learning Toolbox 的 `fitcknn`。不需要 Tensor Toolbox 或 GPU。默认复用分区，因此真实默认实验不调用 ERS MEX；`run_tests(true)` 或重新分割需要包内 ERS MEX。

已验证的环境为 Windows、MATLAB R2023b。`run_tests(false)` 不调用 ERS，但测试包含合成演示，仍需默认分类器使用的 Statistics and Machine Learning Toolbox；false 不代表免除所有工具箱依赖。包内 `mex_ers.mexw64` 是 Windows 二进制；其它平台应配置 C++ 编译器并执行 `build_ers`，未宣称已完成其它平台验收。附带源码与该预编译二进制的构建对应关系未独立确认。

改变窗口、PCA、中心化、划分或分类器属于新的验证设置。重新生成划分/分区须显式设置 `cfg.split_source='generated'`、`cfg.segmentation_source='recompute'`；重算分割采用发布辅助函数，不能自动等同于冻结分区。`cfg.classifier='base_1nn'` 可使用基础 MATLAB 分类器，但未据此宣称截图预测逐位等价。冻结 TDLPP 内核要求 ridge=0、阈值0.005、最多50轮。

## 许可与追溯

ERS 原许可及声明保留在 `THIRD_PARTY_NOTICES.md`。原 PCA/mySVD 辅助函数已随包保留作者和来源说明，未赋予新的整体许可证。冻结代码及资源来源、哈希见 `reproducibility/KERNEL_AND_INPUT_PROVENANCE.json`，数据指纹见 `reproducibility/INPUT_MANIFEST.json`。当前包文件哈希见 `FILE_MANIFEST.csv`。

作者代码尚未配置 `LICENSE`。发布前还需记录 PCA 辅助函数的再分发依据；保留作者注释不能替代许可文件。本版未承诺整个包允许不受限制的商业复用。

发布副本将验证表内的本地绝对路径改为 `local-audit/` 来源标识；它们指向作者本地审计记录，不是本仓库附带文件或运行依赖。代码、固定输入和数值结果未改变。
