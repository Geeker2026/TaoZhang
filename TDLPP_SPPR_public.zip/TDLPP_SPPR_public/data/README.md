# Dataset layout

Datasets are not bundled. Obtain them from their dataset providers under the relevant terms. Supply a `data_root` containing:

| Subdirectory | Cube file / variable | Ground-truth file / variable |
|---|---|---|
| `01_Indian_Pines` | `Indian_pines_corrected.mat` / `indian_pines_corrected` | `Indian_pines_gt.mat` / `indian_pines_gt` |
| `02_Salinas` | `Salinas_corrected.mat` / `salinas_corrected` | `Salinas_gt.mat` / `salinas_gt` |
| `WHU-Hi-HongHu` | `WHU_Hi_HongHu.mat` / `WHU_Hi_HongHu` | `WHU_Hi_HongHu_gt.mat` / `WHU_Hi_HongHu_gt` |
| `Houston` | `Houston.mat` / `Houston` | `Houston_gt.mat` / `Houston_gt` |

Cube arrays are H-by-W-by-B numeric arrays. Ground truth is H-by-W, with 0 denoting unlabeled pixels and positive integers denoting classes. Non-contiguous class IDs are supported. A single combined Houston label map is expected, matching the supplied manuscript's random-sampling protocol; standard provider train/test maps are not automatically substituted or merged.

The default `segmentation_source='frozen'` protocol checks the SHA-256 of the cube and label MAT files against `reproducibility/INPUT_MANIFEST.json` before loading them. This is a byte-level check, not an array-content check. A provider download, conversion or resave can contain equivalent arrays and still fail it. The package currently does not include verified provider download links or a complete conversion procedure that produces the frozen Houston inputs. These preparation details must be supplied for an externally reproducible release; do not bypass the guard and claim equivalence without checking array values, orientation, band selection and label indexing.

To run a separately identified experiment with other compatible inputs, explicitly set `cfg.split_source='generated'` and `cfg.segmentation_source='recompute'`. Recomputation requires ERS and does not establish reproduction of the saved maps, fixed-split validation or manuscript Table 10.

No original paper splits are included. `make_split` returns original-scene linear indices and preserves the caller's RNG state. Training and testing centers are disjoint; spatial patches can overlap, as in a random-pixel transductive protocol.
