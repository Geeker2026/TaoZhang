function [state,metadata] = sppr_segment(X,cfg)
%SPPR_SEGMENT Band scaling -> first PC scores -> uint8 image -> ERS.
if strcmp(cfg.segmentation_source,'frozen')
    a=load(cfg.ers_cache_file,'global_state'); frozen=a.global_state;
    assert(isequal(size(frozen.pseudo_map),size(X,[1 2])) && ...
        frozen.metadata.number_of_bands==size(X,3) && cfg.target_area==800, ...
        'Frozen map shape/representation mismatch.');
    state=sppr_prepare(X,frozen.pseudo_map);
    metadata=struct('K',numel(state.ids),'target_area',800,'lambda',0.5, ...
        'sigma',5,'ground_truth_used',false,'source','frozen_screenshot_map', ...
        'cache_file',cfg.ers_cache_file,'cache_sha256',file_sha256(cfg.ers_cache_file));
    return;
end
assert(strcmp(cfg.segmentation_source,'recompute'),'Unknown segmentation source.');
assert(exist('mex_ers','file')==3, ...
    'ERS MEX missing. Run third_party/ers/build_ers with a C++ compiler.');
[H,W,B]=size(X); K=floor(double(H)*double(W)/cfg.target_area);
assert(K>=2 && K<H*W,'ERS requires 2 <= floor(H*W/target_area) < H*W.');
Y=double(reshape(X,H*W,B)); lo=min(Y,[],1); span=max(Y,[],1)-lo;
span(span==0)=1; Y=(Y-lo)./span;
scores=release_pca(Y,1,true); scores=reshape(scores,H,W);
span=max(scores(:))-min(scores(:));
assert(span>0,'First principal component is constant.');
image=double(uint8(round(255*(scores-min(scores(:)))/span)));
map=mex_ers(image,K,cfg.ers_lambda,cfg.ers_sigma);
assert(numel(unique(map))==K,'ERS returned an unexpected number of regions.');
state=sppr_prepare(X,map);
metadata=struct('K',K,'target_area',cfg.target_area,'lambda',cfg.ers_lambda, ...
    'sigma',cfg.ers_sigma,'ground_truth_used',false,'mex_file',which('mex_ers'));
end
