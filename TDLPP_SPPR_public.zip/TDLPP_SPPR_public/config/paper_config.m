function cfg = paper_config(dataset)
%PAPER_CONFIG Verified unique-candidate SoftClip screenshot protocol.
if nargin<1, dataset='Indian'; end
cfg=struct('version','TDLPP_SPPR_public_unique_softclip_v2','dataset',char(dataset), ...
    'profile','formal_soft_clip_10split','seeds',1001:1010,'window',11,'dimension',50,'train_ratio',0.05, ...
    'train_per_class',[],'test_per_class',[],'minimum_train',10, ...
    'pca_dimension',0,'target_area',800,'ers_lambda',0.5,'ers_sigma',5, ...
    'batch_size',250,'centering','partition','max_iterations',50, ...
    'tolerance',0.005,'ridge',0,'t1',[],'t2',[], ...
    'split_source','frozen','segmentation_source','frozen', ...
    'classifier','frozen_fitcknn','clcr_diagnostics',false);
switch lower(char(dataset))
    case {'indian','indian pines'}
        cfg.dataset='Indian'; cfg.folder='01_Indian_Pines';
        cfg.cube_file='Indian_pines_corrected.mat'; cfg.cube_variable='indian_pines_corrected';
        cfg.gt_file='Indian_pines_gt.mat'; cfg.gt_variable='indian_pines_gt';
    case 'salinas'
        cfg.dataset='Salinas'; cfg.folder='02_Salinas'; cfg.train_ratio=0.01;
        cfg.cube_file='Salinas_corrected.mat'; cfg.cube_variable='salinas_corrected';
        cfg.gt_file='Salinas_gt.mat'; cfg.gt_variable='salinas_gt';
    case {'honghu','whu-hi-honghu'}
        cfg.dataset='HongHu'; cfg.folder='WHU-Hi-HongHu'; cfg.dimension=20;
        cfg.train_per_class=50; cfg.test_per_class=300;
        % Legacy preprocessing, explicitly disclosed rather than inferred from PDF.
        cfg.pca_dimension=80;
        cfg.cube_file='WHU_Hi_HongHu.mat'; cfg.cube_variable='WHU_Hi_HongHu';
        cfg.gt_file='WHU_Hi_HongHu_gt.mat'; cfg.gt_variable='WHU_Hi_HongHu_gt';
    case {'houston','houston2013'}
        cfg.dataset='Houston'; cfg.folder='Houston'; cfg.dimension=15;
        cfg.cube_file='Houston.mat'; cfg.cube_variable='Houston';
        cfg.gt_file='Houston_gt.mat'; cfg.gt_variable='Houston_gt';
    otherwise
        error('Release:Dataset','Unknown dataset: %s',char(dataset));
end
root=fileparts(fileparts(mfilename('fullpath')));
cfg.split_file=fullfile(root,'reproducibility','splits',[cfg.dataset '_outer_splits_v1.mat']);
cfg.ers_cache_file=fullfile(root,'reproducibility','ers_cache', ...
    ['TDLPP_SPPR_GLOBAL_STATE_' cfg.dataset '_w11_A800.mat']);
end
